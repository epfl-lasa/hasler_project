var indexSectionsWithContent =
{
  0: "abcdefghiklmnprstuw",
  1: "bclp",
  2: "abcdehilmptu",
  3: "abcdeghilmpstu",
  4: "abcdefghiklmnprstuw",
  5: "cu",
  6: "acm",
  7: "abfimprsuw",
  8: "abcdefghiklmnprstuw",
  9: "dlm",
  10: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

