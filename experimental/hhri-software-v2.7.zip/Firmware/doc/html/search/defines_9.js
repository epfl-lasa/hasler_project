var searchData=
[
  ['kd_5fcurrent_5fdefault_5fval',['KD_CURRENT_DEFAULT_VAL',['../torque__regulator_8c.html#a7ef468e7e4b360a58e40baad10f1cf06',1,'torque_regulator.c']]],
  ['ki_5fcurrent_5fdefault_5fval',['KI_CURRENT_DEFAULT_VAL',['../torque__regulator_8c.html#a1581decde9a49cbb84bef46c8232a779',1,'torque_regulator.c']]],
  ['kp_5fcurrent_5fdefault_5fval',['KP_CURRENT_DEFAULT_VAL',['../torque__regulator_8c.html#a47c61cbc7d6a4fd8d9886474d42a7f49',1,'torque_regulator.c']]]
];
