var searchData=
[
  ['i2c_5fgpio_5faf',['I2C_GPIO_AF',['../i2c_8h.html#ace864f917126f123b3d467cd69acd3bd',1,'i2c.h']]],
  ['i2c_5fperiph',['I2C_PERIPH',['../i2c_8h.html#a7cb501806cb365f6004e85e0fd53cfec',1,'i2c.h']]],
  ['i2c_5fscl_5fpin',['I2C_SCL_Pin',['../i2c_8h.html#a90aff746759bcec5c2432924a4e87e08',1,'i2c.h']]],
  ['i2c_5fscl_5fpinsource',['I2C_SCL_PinSource',['../i2c_8h.html#a6b351ce95e801899e06ee2d3cdaf42e8',1,'i2c.h']]],
  ['i2c_5fscl_5fport',['I2C_SCL_Port',['../i2c_8h.html#ab72d17a36ff9e28c40bc19338bb02470',1,'i2c.h']]],
  ['i2c_5fsda_5fpin',['I2C_SDA_Pin',['../i2c_8h.html#a6c9bf24a02d97a93266c254da7491798',1,'i2c.h']]],
  ['i2c_5fsda_5fpinsource',['I2C_SDA_PinSource',['../i2c_8h.html#a5df91c9a66dd7edd9176da31121f86ac',1,'i2c.h']]],
  ['i2c_5fsda_5fport',['I2C_SDA_Port',['../i2c_8h.html#a6a35b7c560e90b74461585fc3a40a3cf',1,'i2c.h']]]
];
