var searchData=
[
  ['pc_5fmessage_5fdo_5fnothing',['PC_MESSAGE_DO_NOTHING',['../definitions_8h.html#a411d22e7c2f6c190516cc491240dbfc2a5301cfd336f01cb3cffcb7edcb887fa3',1,'definitions.h']]],
  ['pc_5fmessage_5fget_5fvar',['PC_MESSAGE_GET_VAR',['../definitions_8h.html#a411d22e7c2f6c190516cc491240dbfc2a308f23574ce9559c22d1768ba1a32a58',1,'definitions.h']]],
  ['pc_5fmessage_5fget_5fvars_5flist',['PC_MESSAGE_GET_VARS_LIST',['../definitions_8h.html#a411d22e7c2f6c190516cc491240dbfc2a193b2cb3774186146aac015616cbe811',1,'definitions.h']]],
  ['pc_5fmessage_5fping',['PC_MESSAGE_PING',['../definitions_8h.html#a411d22e7c2f6c190516cc491240dbfc2a9eb90bd7434cd802944b13b40cc74b85',1,'definitions.h']]],
  ['pc_5fmessage_5fset_5fstreamed_5fvar',['PC_MESSAGE_SET_STREAMED_VAR',['../definitions_8h.html#a411d22e7c2f6c190516cc491240dbfc2a1bd3032298ad1f2cb61be777a8199256',1,'definitions.h']]],
  ['pc_5fmessage_5fset_5fvar',['PC_MESSAGE_SET_VAR',['../definitions_8h.html#a411d22e7c2f6c190516cc491240dbfc2a9428220e82d512bcf1a892ed12071aa1',1,'definitions.h']]]
];
