var searchData=
[
  ['pid_5finit',['pid_Init',['../group___p_i_d.html#ga107c7006ccf600d9554ab3bdd7640415',1,'pid_Init(pid_Pid *pid, float32_t kp, float32_t ki, float32_t kd, float32_t arw, float32_t feedforward):&#160;pid.c'],['../group___p_i_d.html#ga107c7006ccf600d9554ab3bdd7640415',1,'pid_Init(pid_Pid *pid, float32_t kp, float32_t ki, float32_t kd, float32_t arw, float32_t feedforward):&#160;pid.c']]],
  ['pid_5fstep',['pid_Step',['../group___p_i_d.html#ga78632d27c4c746218bd946fcab9a2dc8',1,'pid_Step(pid_Pid *pid, float32_t current, float32_t target, float32_t dt):&#160;pid.c'],['../group___p_i_d.html#ga78632d27c4c746218bd946fcab9a2dc8',1,'pid_Step(pid_Pid *pid, float32_t current, float32_t target, float32_t dt):&#160;pid.c']]]
];
