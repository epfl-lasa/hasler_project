var searchData=
[
  ['reduction_5fratio',['REDUCTION_RATIO',['../main_8h.html#a545c3d33941dafc6ffd8cd9a61f6fca4',1,'main.h']]],
  ['reg_5faccel_5fconfig',['REG_ACCEL_CONFIG',['../mpu__6050_8c.html#a7b8e959d8f7fc470648511d3917efee5',1,'mpu_6050.c']]],
  ['reg_5faccel_5fvalues',['REG_ACCEL_VALUES',['../mpu__6050_8c.html#a3e68c47e26d763ecb387fb669d07f752',1,'mpu_6050.c']]],
  ['reg_5fconfig',['REG_CONFIG',['../mpu__6050_8c.html#a679325263fb326462f7410d3292171be',1,'mpu_6050.c']]],
  ['reg_5fgyro_5fconfig',['REG_GYRO_CONFIG',['../mpu__6050_8c.html#aa80ccf68f0f11e35a8ff77039922b43d',1,'mpu_6050.c']]],
  ['reg_5fgyro_5fvalues',['REG_GYRO_VALUES',['../mpu__6050_8c.html#aa827c01620487d285f78e7de565f2f6e',1,'mpu_6050.c']]],
  ['reg_5fpower_5fmgmt_5f1',['REG_POWER_MGMT_1',['../mpu__6050_8c.html#a4435f8f8f18f891d45af3777ae8b1945',1,'mpu_6050.c']]],
  ['reg_5fsig_5fpath_5frst',['REG_SIG_PATH_RST',['../mpu__6050_8c.html#abd35271646192d5fbf90799cddc27842',1,'mpu_6050.c']]],
  ['reg_5fsmplrt_5fdiv',['REG_SMPLRT_DIV',['../mpu__6050_8c.html#a9221fccfb00e441e3ac409d76e37bf20',1,'mpu_6050.c']]],
  ['reg_5ftemp_5fvalues',['REG_TEMP_VALUES',['../mpu__6050_8c.html#a90989c3567a3fed5d325720d9cf7d34d',1,'mpu_6050.c']]],
  ['reg_5fuser_5fctrl',['REG_USER_CTRL',['../mpu__6050_8c.html#a7cd9999e7d20bf5bbd262c3c38d36e31',1,'mpu_6050.c']]],
  ['reg_5fwho_5fam_5fi',['REG_WHO_AM_I',['../mpu__6050_8c.html#a73f4728dfb5c82afcea7bee729af205c',1,'mpu_6050.c']]],
  ['rx_5fbuffer_5fsize',['RX_BUFFER_SIZE',['../ext__uart_8c.html#a739a2a1a0047c98ac1b18ecd25dac092',1,'ext_uart.c']]],
  ['rx_5fdma',['RX_DMA',['../ext__uart_8c.html#a14bb651222cf7dcac90fae75e17134c4',1,'ext_uart.c']]],
  ['rx_5fdma_5fchannel',['RX_DMA_CHANNEL',['../ext__uart_8c.html#aabd835d1f6bed56cbf77681e51cfe4b6',1,'ext_uart.c']]]
];
