var searchData=
[
  ['getfunc',['getFunc',['../structcomm___sync_var.html#a51e7fa1c62d41ed758606ee94e297a4a',1,'comm_SyncVar']]],
  ['gyrofactor',['gyroFactor',['../mpu__6050_8c.html#abfbecdc43f618642c676dfeb1516c78b',1,'mpu_6050.c']]]
];
