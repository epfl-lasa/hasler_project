var searchData=
[
  ['writeonly',['WRITEONLY',['../definitions_8h.html#afbe658a58e414e7d1d9d9a45187de21ba4ffe959f091c61926ed8ff11a75d727e',1,'definitions.h']]]
];
