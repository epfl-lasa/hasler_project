var searchData=
[
  ['name',['name',['../structcomm___sync_var.html#ab01118e003ad3d44c0993cf0cab1baf1',1,'comm_SyncVar']]]
];
