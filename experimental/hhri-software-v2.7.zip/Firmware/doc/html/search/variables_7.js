var searchData=
[
  ['hall_5fchannel',['hall_channel',['../hall_8c.html#a10e613b48d18db9b1b67e099d7d8c789',1,'hall.c']]],
  ['hapt_5fencoderpaddleangle',['hapt_encoderPaddleAngle',['../haptic__controller_8c.html#a165e825a2b232c0e0b24834f962d0bc9',1,'haptic_controller.c']]],
  ['hapt_5fhallvoltage',['hapt_hallVoltage',['../haptic__controller_8c.html#aeb1fa1d1857d8667251d7e8d6b838cff',1,'haptic_controller.c']]],
  ['hapt_5fmotortorque',['hapt_motorTorque',['../haptic__controller_8c.html#a9ebaa0fbf57d5f8c689468ae84b3241f',1,'haptic_controller.c']]],
  ['hapt_5ftimestamp',['hapt_timestamp',['../communication_8c.html#aa073c4da7204a5fa289248686b76ca6d',1,'hapt_timestamp():&#160;haptic_controller.c'],['../haptic__controller_8c.html#aa073c4da7204a5fa289248686b76ca6d',1,'hapt_timestamp():&#160;haptic_controller.c']]]
];
