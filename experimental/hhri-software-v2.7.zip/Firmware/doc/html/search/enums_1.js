var searchData=
[
  ['comm_5fpcmessage',['comm_PcMessage',['../definitions_8h.html#a411d22e7c2f6c190516cc491240dbfc2',1,'definitions.h']]],
  ['comm_5fstmmessage',['comm_StmMessage',['../definitions_8h.html#a5b16f3bf4110dae0d64ebc0f06f3f745',1,'definitions.h']]],
  ['comm_5fvaraccess',['comm_VarAccess',['../definitions_8h.html#afbe658a58e414e7d1d9d9a45187de21b',1,'definitions.h']]],
  ['comm_5fvartype',['comm_VarType',['../definitions_8h.html#a735e597b976fff1607b689ee4637fbb4',1,'definitions.h']]]
];
