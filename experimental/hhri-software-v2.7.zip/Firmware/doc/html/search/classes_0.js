var searchData=
[
  ['bfilt_5fbasicfilter',['bfilt_BasicFilter',['../structbfilt___basic_filter.html',1,'']]]
];
