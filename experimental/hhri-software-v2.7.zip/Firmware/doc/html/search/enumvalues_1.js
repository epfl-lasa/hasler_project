var searchData=
[
  ['bool',['BOOL',['../definitions_8h.html#a735e597b976fff1607b689ee4637fbb4ae663dbb8f8244e122acb5bd6b2c216e1',1,'definitions.h']]]
];
