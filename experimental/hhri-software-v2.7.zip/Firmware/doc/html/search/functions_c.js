var searchData=
[
  ['tim10initfunc',['tim10InitFunc',['../callback__timers_8c.html#ad139b4bab91998be1865e9f96e2cf7d1',1,'callback_timers.c']]],
  ['tim1_5fup_5ftim10_5firqhandler',['TIM1_UP_TIM10_IRQHandler',['../callback__timers_8c.html#ad1fd361bc5ad89facee67c76d1ff8dc0',1,'callback_timers.c']]],
  ['tim5initfunc',['tim5InitFunc',['../incr__encoder_8c.html#a8d5f684c1c4e7b8cd243a3ff783ea830',1,'incr_encoder.c']]],
  ['tim67initfunc',['tim67InitFunc',['../callback__timers_8c.html#a2352e508b37b3b9d34e2a2363427f370',1,'callback_timers.c']]],
  ['tim6_5fdac_5firqhandler',['TIM6_DAC_IRQHandler',['../callback__timers_8c.html#a0839a45f331c4c067939b9c4533bbf4d',1,'callback_timers.c']]],
  ['tim7_5firqhandler',['TIM7_IRQHandler',['../callback__timers_8c.html#a98cff83252098363b2dbca9608df964e',1,'callback_timers.c']]],
  ['torq_5finit',['torq_Init',['../group___torque_regulator.html#gaaa69a20ae7d3f8c5cef91f55ca51d2c9',1,'torq_Init(void):&#160;torque_regulator.c'],['../group___torque_regulator.html#gaaa69a20ae7d3f8c5cef91f55ca51d2c9',1,'torq_Init(void):&#160;torque_regulator.c']]],
  ['torq_5fregulatecurrent',['torq_RegulateCurrent',['../torque__regulator_8c.html#adfe454f532c8c18c8b716485bca7ec77',1,'torque_regulator.c']]],
  ['torq_5fsettorque',['torq_SetTorque',['../group___torque_regulator.html#ga19c916f86f339e0151fdbb5344416c4f',1,'torq_SetTorque(float32_t torque):&#160;torque_regulator.c'],['../group___torque_regulator.html#ga19c916f86f339e0151fdbb5344416c4f',1,'torq_SetTorque(float32_t torque):&#160;torque_regulator.c']]],
  ['torq_5fstartcurrentloop',['torq_StartCurrentLoop',['../group___torque_regulator.html#gaf6be6faa2e7e327373ae2e02808fa7bf',1,'torq_StartCurrentLoop(void):&#160;torque_regulator.c'],['../group___torque_regulator.html#gaf6be6faa2e7e327373ae2e02808fa7bf',1,'torq_StartCurrentLoop(void):&#160;torque_regulator.c']]]
];
