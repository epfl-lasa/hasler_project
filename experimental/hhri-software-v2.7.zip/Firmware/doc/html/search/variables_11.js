var searchData=
[
  ['uart_5fcurrenttxbuffertowriteto',['uart_currentTxBufferToWriteTo',['../uart_8c.html#ace1f65984b3dc695536ca855d1b49821',1,'uart.c']]],
  ['uart_5fnbytestotransferdma',['uart_nBytesToTransferDma',['../uart_8c.html#aaaf8ec2f0f7d9b9c25cfaa4caa9d00b0',1,'uart.c']]],
  ['uart_5frxbuffer',['uart_rxBuffer',['../uart_8c.html#a61e91fe6c76d6ec849a0a5522e364f2c',1,'uart.c']]],
  ['uart_5frxbufftail',['uart_rxBuffTail',['../uart_8c.html#a0d0c19e2750e0be4523e5ea4360df392',1,'uart.c']]],
  ['uart_5frxqueue',['uart_rxQueue',['../uart_8c.html#a2fb0d3bfb561244d972be5a129f84180',1,'uart.c']]],
  ['uart_5ftxbuffer',['uart_txBuffer',['../uart_8c.html#a5f2cd2c42c4c8adc5d33c3aff65f49a3',1,'uart.c']]],
  ['uart_5ftxbufferindex',['uart_txBufferIndex',['../uart_8c.html#a32ca96327c5840cddaacbbe4f22f8793',1,'uart.c']]],
  ['uart_5fuserrxqueue',['uart_userRxQueue',['../uart_8c.html#acabaf9e05c673d680fbf946803f8c239',1,'uart.c']]],
  ['userbuttonstatechangedcallback',['userButtonStateChangedCallback',['../button_8c.html#adb4fa1ed449dec8b41603e5364e76564',1,'button.c']]],
  ['usesvaraddress',['usesVarAddress',['../structcomm___sync_var.html#aced3e271d5e89cecd5dcadae3d240fc8',1,'comm_SyncVar']]]
];
