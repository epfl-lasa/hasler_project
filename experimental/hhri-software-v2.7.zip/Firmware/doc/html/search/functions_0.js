var searchData=
[
  ['adc_5fcalibratecurrentsens',['adc_CalibrateCurrentSens',['../group___a_d_c.html#gaf411690d45e823208d57d7b6c6b03177',1,'adc_CalibrateCurrentSens(void):&#160;adc.c'],['../group___a_d_c.html#gaf411690d45e823208d57d7b6c6b03177',1,'adc_CalibrateCurrentSens(void):&#160;adc.c']]],
  ['adc_5fconversionisfinished',['adc_ConversionIsFinished',['../adc_8c.html#a1d73df3bbbf62d3ab2063df66ceb7fae',1,'adc.c']]],
  ['adc_5fdmainit',['adc_DmaInit',['../adc_8c.html#a06853b5da01862f8d672ac7cbda1c6ff',1,'adc.c']]],
  ['adc_5fgetchannelvoltage',['adc_GetChannelVoltage',['../group___a_d_c.html#ga97fe15ac16537b1fd63e8c279f77f758',1,'adc_GetChannelVoltage(AdcChannel channel):&#160;adc.c'],['../group___a_d_c.html#ga97fe15ac16537b1fd63e8c279f77f758',1,'adc_GetChannelVoltage(AdcChannel channel):&#160;adc.c']]],
  ['adc_5fgetconversionresult',['adc_GetConversionResult',['../adc_8c.html#ad0eaf25cc0d3fbf8a3c5c0c6054ae34a',1,'adc.c']]],
  ['adc_5fgetcurrent',['adc_GetCurrent',['../group___a_d_c.html#ga34e13f55864e71f73d21a53e706f5f68',1,'adc_GetCurrent(void):&#160;adc.c'],['../group___a_d_c.html#ga34e13f55864e71f73d21a53e706f5f68',1,'adc_GetCurrent(void):&#160;adc.c']]],
  ['adc_5finit',['adc_Init',['../group___a_d_c.html#ga60eec0e847f5b4d863a4eacfe8fed380',1,'adc_Init(void):&#160;adc.c'],['../group___a_d_c.html#ga60eec0e847f5b4d863a4eacfe8fed380',1,'adc_Init(void):&#160;adc.c']]],
  ['adc_5fstartconversion',['adc_StartConversion',['../adc_8c.html#afa4a627a47389c5df402099f598561c3',1,'adc.c']]]
];
