var searchData=
[
  ['motor_5fnominal_5ftorque',['MOTOR_NOMINAL_TORQUE',['../main_8h.html#a3fa20f3334c8d3d603c6825f6bb0fbf7',1,'main.h']]],
  ['motor_5fresistance',['MOTOR_RESISTANCE',['../main_8h.html#abdeaba0790a7db1dddb92b7557220929',1,'main.h']]],
  ['motor_5fspeed_5fconst',['MOTOR_SPEED_CONST',['../main_8h.html#a1b1832f99376ca51201b12e2dddeba7d',1,'main.h']]],
  ['motor_5ftorque_5fconst',['MOTOR_TORQUE_CONST',['../main_8h.html#a5717dc4a3151be3c313e319d88f5459c',1,'main.h']]]
];
