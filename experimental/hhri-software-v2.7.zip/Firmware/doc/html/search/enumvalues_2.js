var searchData=
[
  ['float32',['FLOAT32',['../definitions_8h.html#a735e597b976fff1607b689ee4637fbb4a2644b741f40df4c4c3a83bbdcf7124b3',1,'definitions.h']]],
  ['float64',['FLOAT64',['../definitions_8h.html#a735e597b976fff1607b689ee4637fbb4aa1f95514c315d551fb2d44d8a5bc6ee2',1,'definitions.h']]]
];
