var searchData=
[
  ['readonly',['READONLY',['../definitions_8h.html#afbe658a58e414e7d1d9d9a45187de21ba626af06d585fcb18d2cd6cdec0d235cf',1,'definitions.h']]],
  ['readwrite',['READWRITE',['../definitions_8h.html#afbe658a58e414e7d1d9d9a45187de21ba35c9731eb1af206e4ebcfc0bc95cd6de',1,'definitions.h']]]
];
