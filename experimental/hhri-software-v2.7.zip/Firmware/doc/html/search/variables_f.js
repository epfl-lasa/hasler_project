var searchData=
[
  ['selectedvariablestostream',['selectedVariablesToStream',['../communication_8c.html#aa50e688124d0dd21a3bb032ebd846f63',1,'communication.c']]],
  ['setfunc',['setFunc',['../structcomm___sync_var.html#a2a26b280d3b51cd70489c703e09e244c',1,'comm_SyncVar']]],
  ['size',['size',['../structcomm___sync_var.html#ae5dc6ffcd9b7605c7787791e40cc6bb0',1,'comm_SyncVar']]]
];
