var searchData=
[
  ['torque_5fregulator_2ec',['torque_regulator.c',['../torque__regulator_8c.html',1,'']]],
  ['torque_5fregulator_2eh',['torque_regulator.h',['../torque__regulator_8h.html',1,'']]]
];
