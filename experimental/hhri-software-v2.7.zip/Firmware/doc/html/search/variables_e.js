var searchData=
[
  ['readindex',['readIndex',['../structcb___circular_buffer.html#ae6fb110fa9cf13508f6c6464e9f15c44',1,'cb_CircularBuffer']]],
  ['rxbytescount',['rxBytesCount',['../communication_8c.html#abb1ea170e9788daf586998b5c918d787',1,'communication.c']]],
  ['rxcurrentmessagetype',['rxCurrentMessageType',['../communication_8c.html#acdb326425d91007df980986578dc0929',1,'communication.c']]],
  ['rxdatabytesbuffer',['rxDataBytesBuffer',['../communication_8c.html#a48ffd415da84c4003dd3e364f9affada',1,'communication.c']]]
];
