var searchData=
[
  ['n_5fgpios',['N_GPIOS',['../debug__gpio_8c.html#aae2e397646c03f33d203421a9b023615',1,'debug_gpio.c']]],
  ['n_5fleds',['N_LEDS',['../led_8c.html#ae141ceb34938aab59b3009736e72a427',1,'led.c']]],
  ['n_5fsyncvars_5fmax',['N_SYNCVARS_MAX',['../definitions_8h.html#a4e7e031f9e0e2e93ffbd962773973eaf',1,'definitions.h']]],
  ['nfault_5fpin',['nFAULT_Pin',['../h__bridge_8h.html#a06338964efb82ca40635f6e10add1b0b',1,'h_bridge.h']]],
  ['nfault_5fport',['nFAULT_Port',['../h__bridge_8h.html#a014a9153393345f9b9bfc5b333a50e66',1,'h_bridge.h']]],
  ['nsleep_5fpin',['nSLEEP_Pin',['../h__bridge_8h.html#ae79fa0b3f425ea215fce1ee8b9f02d1d',1,'h_bridge.h']]],
  ['nsleep_5fport',['nSLEEP_Port',['../h__bridge_8h.html#ad407278ca4afc7332068c45c6b9bc4a2',1,'h_bridge.h']]]
];
