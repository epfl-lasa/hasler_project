var searchData=
[
  ['hall_5fgetvoltage',['hall_GetVoltage',['../group___hall.html#gab59cc0073045afc3f6f00ee9ad0e257e',1,'hall_GetVoltage(void):&#160;hall.c'],['../group___hall.html#gab59cc0073045afc3f6f00ee9ad0e257e',1,'hall_GetVoltage(void):&#160;hall.c']]],
  ['hall_5finit',['hall_Init',['../group___hall.html#gaec0d308c1b1ee0e317c2dc9610432751',1,'hall_Init(AdcChannel channel):&#160;hall.c'],['../group___hall.html#gaec0d308c1b1ee0e317c2dc9610432751',1,'hall_Init(AdcChannel channel):&#160;hall.c']]],
  ['hapt_5finit',['hapt_Init',['../group___haptic_controller.html#ga5a34049e196fada506871b4dde8c08ce',1,'hapt_Init(void):&#160;haptic_controller.c'],['../group___haptic_controller.html#ga5a34049e196fada506871b4dde8c08ce',1,'hapt_Init(void):&#160;haptic_controller.c']]],
  ['hapt_5fupdate',['hapt_Update',['../haptic__controller_8c.html#aefe1ed0a0c682de3d0bdb4c8db8b2fa2',1,'haptic_controller.c']]],
  ['hb_5fdisable',['hb_Disable',['../group___h___bridge.html#ga1d7cca8225111d5cdca1ed21245d8065',1,'hb_Disable():&#160;h_bridge.c'],['../group___h___bridge.html#ga1d7cca8225111d5cdca1ed21245d8065',1,'hb_Disable(void):&#160;h_bridge.c']]],
  ['hb_5fenable',['hb_Enable',['../group___h___bridge.html#ga642aab843acbf878564d738e200213d3',1,'hb_Enable():&#160;h_bridge.c'],['../group___h___bridge.html#ga642aab843acbf878564d738e200213d3',1,'hb_Enable(void):&#160;h_bridge.c']]],
  ['hb_5fhasfault',['hb_HasFault',['../group___h___bridge.html#gaa55b32a4c2fa2408743c308d113e493d',1,'hb_HasFault(void):&#160;h_bridge.c'],['../group___h___bridge.html#gaa55b32a4c2fa2408743c308d113e493d',1,'hb_HasFault(void):&#160;h_bridge.c']]],
  ['hb_5finit',['hb_Init',['../group___h___bridge.html#gac68193eec3674433ab4de51b5365d67a',1,'hb_Init(void):&#160;h_bridge.c'],['../group___h___bridge.html#gac68193eec3674433ab4de51b5365d67a',1,'hb_Init(void):&#160;h_bridge.c']]],
  ['hb_5fsetpwm',['hb_SetPWM',['../group___h___bridge.html#ga47cbe3068b1b9b9a7b774c7a860b741f',1,'hb_SetPWM(float32_t ratio):&#160;h_bridge.c'],['../group___h___bridge.html#ga47cbe3068b1b9b9a7b774c7a860b741f',1,'hb_SetPWM(float32_t ratio):&#160;h_bridge.c']]],
  ['hb_5ftim8init',['hb_Tim8Init',['../h__bridge_8c.html#aeddf39bb704200fd17337b3475b75074',1,'h_bridge.c']]]
];
