var searchData=
[
  ['board_5fbutton_5fpin',['BOARD_BUTTON_PIN',['../button_8c.html#aa4cd65d8b2e2a964c7baec1bfaff0365',1,'button.c']]],
  ['board_5fbutton_5fport',['BOARD_BUTTON_PORT',['../button_8c.html#ab0772e998ced7bee138ca302f2b65b50',1,'button.c']]]
];
