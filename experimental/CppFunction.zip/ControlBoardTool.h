#define		USE_NEW_MOTOR_DRIVER_BOARD

#define 	axis0ID 			            ((unsigned char)0)
#define 	axis1ID				            ((unsigned char)1)
#define 	axis2ID				            ((unsigned char)2)
#define 	axis0_RegID 			        ((unsigned char)1)
#define 	axis1_RegID				        ((unsigned char)2)
#define 	axis2_RegID				        ((unsigned char)4)

typedef enum {
  DISABLE = 0,
  ENABLE = !DISABLE
} FunctionalState;


/* List of the parameter of eaah axis -------------------------------- */
/* They all can be acces trough the "axis_get_param()" function ------ */
/* Some can be set using "axis_set_param()" function ----------------- */
typedef enum{
	status								= 0,
	error								= 1,
	currentTarget_A						= 2,
	currentMeasure_A					= 3,
	currentMeasure_A_filtered			= 4,
	currentReg_Ki						= 5,
	currentReg_Kp						= 6,
	currentReg_Kv						= 7,
	currentReg_Kr						= 8,
	currentReg_integ					= 9,
	currentReg_integLim					= 10,
	currentLim_A						= 11,
	timerCoderResol						= 12,
	timerCoderOverflowCnt				= 13,
	coderResol_incRevol					= 14,
	positionTarget_inc 					= 15,
	positionMeasure_inc 				= 16,
	positionMeasure_inc_old				= 17,
	positionError_deg_old				= 18,
	speed_degps							= 19,
	positionReg_Kp						= 20,
	positionReg_Ki						= 21,
	positionReg_Kd						= 22,
	positionReg_integ					= 23,
	positionReg_integLim				= 24,
	positionRegCurrentScale				= 25,
	currentRegTs_us						= 26,
	positionRegTs_us					= 27,
	posLoopExecutionTime_us_			= 28,
	maxPosLoopExecutionTime_us_			= 29,
	currentLoopExecutionTime_us_		= 30,
	maxCurrentLoopExecutionTime_us_		= 31,
	estimatedTemperature_c 				= 32,
	max_speed_incpcycle					= 33,
	initPosition_deg 					= 34,
}axis_paramID;


int		openSerialConnexion(HANDLE * comport);
int		setRobotWorkingMode(HANDLE ComPort, int modeID);
unsigned int getMainStatusReg(HANDLE ComPort);
unsigned int getUcProgramVersion(HANDLE ComPort);

int		syncDataStream_CMD(HANDLE ComPort, FunctionalState NewState, int CheckOk = 0);
int		asyncDataStream_CMD(HANDLE ComPort, FunctionalState NewState, int CheckOk = 0);

void	RequestAllAxisInit(HANDLE ComPort);
int     axis_set_all_control_param(HANDLE ComPort);
int     axis_set_param(HANDLE ComPort, unsigned char axisID, axis_paramID ParamID, float ParamValue, int CheckOk = 0);
float   axis_get_param(HANDLE ComPort, unsigned char axisID, axis_paramID ParamID);
int     axis_CMD(HANDLE ComPort, FunctionalState axis0_NewState, FunctionalState axis1_NewState, FunctionalState axis2_NewState, int CheckOk = 0);

int		dryFrictionMode_CMD(HANDLE ComPort, FunctionalState NewState, int CheckOk = 0);

int		Set_AllAxis_Position_Offset(HANDLE ComPort, double *AxisActualPos_rad);
void    Set_AllMotors_Position_Targuet(HANDLE ComPort, double *AxisTargetPos_rad, int dummyTarget = 0);
void    Set_AllMotors_Current_Targuet(HANDLE ComPort, double *MotorCurrent_Amp, int dummyTarget = 0);

void	Set_AllAnalogInput_Offset(void);

void    Get_AllAxis_Last_Recieved_Position(double *AxisMeasuredPos_rad);
void	Get_AllAnalogInput_Last_Recieved_Value(double *AnalogInput);

// Obsolete function 
void	Request_AllAxis_Position(HANDLE ComPort, double *AxisMeasuredPos_rad);
void	Request_AllAnalogInput(HANDLE ComPort, double *AnalogInput);
