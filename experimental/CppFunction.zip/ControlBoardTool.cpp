///////////////////////////////////////////////////////////////////////////////////////////////////
//  ControlBoardTool.cpp
///////////////////////////////////////////////////////////////////////////////////////////////////
//  This source file includes functions for communication with the motor control/driver electric board
//	In principle the user only needs to use the 5 folowing functions
//		openSerialConnexion
//			-> Open serial communication with the board
//		setRobotWorkingMode
//			-> Performs the different initialisation/configuration steps and verifications to set the robots working mode
//		Set_AllMotors_Position_Targuet
//		Get_AllAxis_Last_Recieved_Position
//		Get_AllAnalogInput_Last_Recieved_Value
///////////////////////////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//  Programmer:		Laurent Jenni (fluffy guinea pigs enthusiast)
//  Affiliation:	No idea
//  Created date:	Somewhere between 2017 and 2018
//	Updated date:	Change all the time
///////////////////////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <bitset>
#include <cmath>

#include "ControlBoardTool.h"

using namespace std;


//#define     MDF_DEBUG_EN
#define	  GET_1_ANALOG_INPUT
//#define		GET_AXIS_TORQUE
#define		MAX_REQUEST_ATTEMPS						5

#define		RAD2DEG									57.295779513082321
#define		DEG2RAG									0.0174532925199433
#define		ANALOG_INPUT_SCALING_GAIN				0.025

/* MSG_TYPE_ID ----------------------------------------------------- */
#define 	MSG_TYPE_DEBUG							((unsigned char)255) 
#define 	MSG_TYPE_GENERAL_CONFIG					((unsigned char)254) 
#define 	MSG_TYPE_POSITION_CONTROL				((unsigned char)249) 	//Protocol principal lors du fonctionnement normal
#define 	MSG_TYPE_CURRENT_CONTROL				((unsigned char)248) 	//Protocol principal lors du fonctionnement normal
#define 	MSG_TYPE_GET_POSITION					((unsigned char)247) 	//Get all 3 positions (deg)
#define 	MSG_TYPE_GET_ANALOG_INPUT				((unsigned char)246) 	//Get all 3 analog input
#define 	MSG_STOP								((unsigned char)170)	//Stop frame

/* GENERAL_CONFIG_REQUEST_ID --------------------------------------- */
/* associated with message type "MSG_TYPE_GENERAL_CONFIG" ---------- */
#define 	CONFIG_REQUEST_SET_AXIS_PARAM			((unsigned char)0) 
#define		CONFIG_REQUEST_GET_AXIS_PARAM			((unsigned char)1)
#define		CONFIG_REQUEST_EN_DIS_AXIS_CMD			((unsigned char)2)
#define 	CONFIG_REQUEST_SET_ZERO_REF				((unsigned char)3) 	//Set actual position of the robot as the new reference position (all motors angular position = 0�)
#define		CONFIG_REQUEST_EN_SYNC_DATA_STREAM		((unsigned char)4)
#define		CONFIG_REQUEST_DIS_SYNC_DATA_STREAM		((unsigned char)5)
#define		CONFIG_REQUEST_EN_ASYNC_DATA_STREAM		((unsigned char)6)
#define		CONFIG_REQUEST_DIS_ASYNC_DATA_STREAM	((unsigned char)7)
#define     CONFIG_REQUEST_GET_MAIN_STATUS_REG		((unsigned char)8)
#define     CONFIG_REQUEST_AXIS_INIT                ((unsigned char)9)
#define     CONFIG_REQUEST_EN_DRY_FRICTION_MODE     ((unsigned char)10)
#define     CONFIG_REQUEST_DIS_DRY_FRICTION_MODE    ((unsigned char)11)
#define     CONFIG_REQUEST_SET_MOTOR_OFF_MODE		((unsigned char)12)
#define     CONFIG_REQUEST_GET_UC_PROGRAM_VERSION	((unsigned char)26)

/* Main Status bits ------------------------------------------------ */
#define		RUN_SUPPERVISION_LOOP					0x00000001
#define		STREAM_DATA_EN							0x00000002
#define		SYNC_REPLY_STREAM_EN					0x00000004
#define		PROGRAM_VERSION_LISTED					0x00000008  //Is set if if the "programVersion" variable is avalaible
#define		UART_PACKET_SUCCES						0x00000010	//Set if (at least) one valid packet recieved from PC
#define		REQUEST_AXIS_INIT 						0x00000020
#define		AXIS_INIT_IN_PROGRESS 					0x00000040
#define		AXIS_GENERAL_ERROR_FLAG					0x00000100	//An error occur during the "axis_suppervision_Loop" (p.ex. Extern emergency stop) check "Axis[i].error" for detail
#define		MOTOR_OFF_MODE							0x10000000
#define		WORKING_MODE_LOCKED						0x20000000
#define		GENERAL_PURPOSE_TOGGLE_FLAG 			0x40000000  //Toggle by the board to confirm recetion of message for certain type of message
#define		THIS_BIT_ALWAYS_SET 					0x80000000 	//The MSB of mainStatus register should always be set ("dummy" used by the PC to test if board answer)

/* Axis Status bits ------------------------------------------------ */
#define 	AXIS_ERROR								0x00000001	//Set to one when an error occure (see axisTypeDef.error)
#define 	AXIS_LOCK_MODE 							0x00000002	//When this bit is set the user has limited action over the axis -> not possible to set axis param (including current/position target), not possible to enable/disable axis
#define 	MOTOR_EN 								0x00000004	
#define 	MOTOR_EN_USER 							0x00000008	//This bit is set when the user want the motor to be enable (but will not necessary be effective if a security issue is detected)
#define 	DISABLE_POSITION_LOOP					0x00000010	//If set-> bypass the position loop to allows current control
#define		AXIS_INIT_FAULT							0x00000020
#define 	AXIS_INIT_SUCCES 						0x00000040
#define 	VIRTUAL_DRY_FRICTION_EN					0x00000080	//If set, and the axis is enable (not in current regulation mode) -> generate a virtual dry friction

/* Local Status bits ------------------------------------------------ */
#define		SERIAL_CONNEXION_OPEN_SUCCES			0x00000001	//Set when the serial connexion is open
#define		SYNC_REPLY_STREAM_EN_SUCCES				0x00000002	//Set when the sync reply is on
#define		ALL_AXIS_INIT_SUCCES					0x00000004	//Set when all the 3 axis have been all initialised successfully
#define		ALL_AXIS_OFFSET_SUCCES					0x00000008	//Set position offset

static unsigned int LocalStatus = 0;


#define     BUFFER_SIZE		256

unsigned char		rxDataBuffer[BUFFER_SIZE];
unsigned char		txDataBuffer0[BUFFER_SIZE];
unsigned char		txDataBuffer1[BUFFER_SIZE];

unsigned char		txBufferID 	    = 0;
unsigned char		txBufferCnt 	= 0;

bool				lockTx			= false;


typedef struct{
	float PositionReg_Kp;
	float PositionReg_Kd;
	float PositionReg_Ki;
	float PositionReg_IntegLim;
	float PositionReg_CurrentScale;
	float PositionReg_Ts_us;
	float CurrentReg_Kp;
	float CurrentReg_Ki;
	float CurrentReg_Kv;
	float CurrentReg_Kr;
	float CurrentReg_MaxCurrent;
	float Coder_Resol;
	double Gear_GearRatio;
	double AxisMeasuredPos_rad;
	double AxisPosOffset_rad;
}AxisTypeDef;


AxisTypeDef Axis[3]={
	{
		0.25f,		// PositionReg_Kp,
		0.002f,		// PositionReg_Kd,
		2.0f,		// PositionReg_Ki,
		1.5f,		// PositionReg_IntegLim,
		-1.0f,		// PositionReg_CurrentScale,
		350.0f,		// PositionReg_Ts_us,
		0.8f,		// CurrentReg_Kp,
		1.0f,		// CurrentReg_Ki,
		0.0f,		// CurrentReg_Kv,
		1.3f,		// CurrentReg_Kr,
		5.0f,		// CurrentReg_MaxCurrent,
		16384.0f,	// Coder_Resol,
		14.0f,		// Gear_GearRatio,
		0.0,		// AxisMeasuredPos_rad,
		0.0,		// AxisPosOffset_rad,
	},{
		0.25f,		// PositionReg_Kp,
		0.002f,		// PositionReg_Kd,
		2.0f,		// PositionReg_Ki,
		1.5f,		// PositionReg_IntegLim,
		-1.0f,		// PositionReg_CurrentScale,
		350.0f,		// PositionReg_Ts_us,
		0.8f,		// CurrentReg_Kp,
		1.0f,		// CurrentReg_Ki,
		0.0f,		// CurrentReg_Kv,
		1.3f,		// CurrentReg_Kr,
		5.0f,		// CurrentReg_MaxCurrent,
		16384.0f,	// Coder_Resol,
		14.0f,		// Gear_GearRatio,
		0.0,		// AxisMeasuredPos_rad,
		0.0,		// AxisPosOffset_rad,
	},{
		0.25f,		// PositionReg_Kp,
		0.002f,		// PositionReg_Kd,
		2.0f,		// PositionReg_Ki,
		1.5f,		// PositionReg_IntegLim,
		-1.0f,		// PositionReg_CurrentScale,
		350.0f,		// PositionReg_Ts_us,
		0.8f,		// CurrentReg_Kp,
		1.0f,		// CurrentReg_Ki,
		0.0f,		// CurrentReg_Kv,
		1.3f,		// CurrentReg_Kr,
		5.0f,		// CurrentReg_MaxCurrent,
		16384.0f,	// Coder_Resol,
		14.0f,		// Gear_GearRatio,
		0.0,		// AxisMeasuredPos_rad,
		0.0,		// AxisPosOffset_rad,
	}
};

//float		MotorActualPosDeg[3]		= {0.0f,0.0f,0.0f};
float		DummyAnalogInput[3]			= {0.0f,0.0f,0.0f};
float 		DummyAnalogInputOffset[3]	= {0.0f,0.0f,0.0f};
float		DummyMotorTorque[3]			= {0.0f,0.0f,0.0f};


/* Private function ------------------------------------------------ */
static unsigned int	private_ConvBits2uint32(unsigned char Uint32ByteStartID);
static float	    private_ConvBits2float(unsigned char FloatByteStartID);
static void			private_add_7BitChar_To_TxBuffer(unsigned char DATA);
static void			private_add_8BitChar_To_TxBuffer(unsigned char DATA);
static void 		private_add_uint32_To_TxBuffer(unsigned int DATA);
static void			private_add_float_To_TxBuffer(float DATA);
static void			private_TX_add_CCR(void);
static int			private_RX_check_CCR(int RxBufferMsgStartID, int RxBufferMsgEndID);
static void			private_reset_txBuffer(void);
static void			private_send_txBuffer(HANDLE ComPort);




/**
  * @brief  This function alows to set the different working mode of the robot. 
  *			When selecting a working mode it will performs the necessary verification to avoid 
  *			bad beaviour. 
  * @return 0->if succes
*/
int		setRobotWorkingMode(HANDLE ComPort, int modeID){

#ifdef NO_ROBOT
	return 0;
#endif

// ----------------------------------------------------------------------------------
// Check if serial is open
	if(!(LocalStatus & SERIAL_CONNEXION_OPEN_SUCCES))
		return -99998;

// ----------------------------------------------------------------------------------
// Check if Sync reply is on (and turn it on if not)
	if(!(LocalStatus & SYNC_REPLY_STREAM_EN_SUCCES) && !(modeID==-1)){
		for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
			if(syncDataStream_CMD(ComPort, ENABLE, 1)==0){
				LocalStatus |= SYNC_REPLY_STREAM_EN_SUCCES;
				goto pouette1;
			}
			Sleep(20);
		}
		return -99997;	// unable to start sync reply
	}

pouette1:


	switch(modeID){

// ----------------------------------------------------------------------------------
// Turn off all motor bridges (in principle used just before quiting the programm)
	case -1:
		for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
			if(axis_CMD(ComPort, DISABLE, DISABLE, DISABLE,1)==0)
				return 0;
			Sleep(20);
		}
		return -99996;	//unable to stop bridge

// ----------------------------------------------------------------------------------
// Set the robot in dry-friction mode and turn on the syc_reply (if not already enable)
	case 0:
		for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
			if(dryFrictionMode_CMD(ComPort,ENABLE,1)==0){
				goto case0_1;
			}
			Sleep(20);
		}
		return -99995;	// unable to go to dry-friction mode
		case0_1:
		for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
			if(axis_CMD(ComPort, ENABLE, ENABLE, ENABLE,1)==0){
				return 0; // OK
			}
			Sleep(20);
		}
		return -99994;	// Able to go to dry-friction mode but unable to start the motor power bridge

// ----------------------------------------------------------------------------------
// Start axis calibration
	case 1:
		unsigned int mainStatusReg,mainStatusReg2;
		mainStatusReg = getMainStatusReg(ComPort);
		mainStatusReg2 = mainStatusReg;
		for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
			RequestAllAxisInit(ComPort);
			Sleep(20);
			mainStatusReg2 = getMainStatusReg(ComPort);
			if( (mainStatusReg & GENERAL_PURPOSE_TOGGLE_FLAG) != (mainStatusReg2 & GENERAL_PURPOSE_TOGGLE_FLAG) ){
				LocalStatus &=~ALL_AXIS_INIT_SUCCES;	//clear possible previous initialisation succes flag
				LocalStatus &=~ALL_AXIS_OFFSET_SUCCES;
				return 0;
			}
		}
		return -99993; //Unable to start axis calibration

// ----------------------------------------------------------------------------------
// Set regular position control mode (turn off dry friction mode)
// !!!!!!!!!! 
// !!!!!!!!!! AJOUTER UN TRUC QUI VERIFIE QUE L'ERREUR DE POSITION EST PAS TROP GRANDE (AKA. LE ROBOT A PAS TROP BOUG� DEPUIS LA MISE � JOUR DE L'OFFSET)
// !!!!!!!!!! 
	case 2:
		if(!(LocalStatus & ALL_AXIS_OFFSET_SUCCES)){
			return -99992;	//Init should be done first
		}

		for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
			if(dryFrictionMode_CMD(ComPort, DISABLE,1)==0)
				return 0;
			Sleep(20);
		}
		return -99991;	//unable to stop dry friction mode
// ----------------------------------------------------------------------------------
// Wrong request
	default:
		return -99999; //Wrong request
	}
}

/**
  * @brief	
  * @param
  * @retval -999 ->Error 0 ->Succes
  */
int		openSerialConnexion(HANDLE * comport){
#ifdef NO_ROBOT
	return 0;
#else
    int             bStatus;
    DCB             comSettings;          // Contains various port settings
    COMMTIMEOUTS    CommTimeouts;
    LPCSTR          PortNameID_list_becauseImMechanicIngenierAndIdontKnowHowToCodeLeaveMeAlone[34] = {
						"\\\\.\\COM1","\\\\.\\COM2","\\\\.\\COM3","\\\\.\\COM4","\\\\.\\COM5","\\\\.\\COM6","\\\\.\\COM7","\\\\.\\COM8","\\\\.\\COM9",
        "\\\\.\\COM10","\\\\.\\COM11","\\\\.\\COM12","\\\\.\\COM13","\\\\.\\COM14","\\\\.\\COM15","\\\\.\\COM16","\\\\.\\COM17","\\\\.\\COM18","\\\\.\\COM19",
        "\\\\.\\COM20","\\\\.\\COM21","\\\\.\\COM22","\\\\.\\COM23","\\\\.\\COM24","\\\\.\\COM25","\\\\.\\COM26","\\\\.\\COM27","\\\\.\\COM28","\\\\.\\COM29",
		"\\\\.\\COM30","\\\\.\\COM31","\\\\.\\COM32","\\\\.\\COM33","\\\\.\\COM34"};
    LPCSTR          PortNameID;
    // Open COM port
    for(int i=0; i<34; i++){
        PortNameID = PortNameID_list_becauseImMechanicIngenierAndIdontKnowHowToCodeLeaveMeAlone[i];
        if (!((*comport = CreateFile(PortNameID, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL)) == INVALID_HANDLE_VALUE)){
            //returnStatus = 1;
            CommTimeouts.ReadIntervalTimeout         = 100;
            CommTimeouts.ReadTotalTimeoutMultiplier  = 100;
            CommTimeouts.ReadTotalTimeoutConstant    = 100;
            CommTimeouts.WriteTotalTimeoutMultiplier = 100;
            CommTimeouts.WriteTotalTimeoutConstant   = 100;
            bStatus = SetCommTimeouts(*comport,&CommTimeouts);
            if (bStatus != 0){}// error processing code here

            GetCommState(*comport, &comSettings);
            comSettings.BaudRate = 1843200;//.921600;
            comSettings.StopBits = ONESTOPBIT;
            comSettings.ByteSize = 8;
            comSettings.Parity   = NOPARITY;
            comSettings.fParity  = FALSE;
            bStatus = SetCommState(*comport, &comSettings);
            if (bStatus != 0){}// error processing code here

            if(getMainStatusReg(*comport)){ //Test if Motor board respond ok
				LocalStatus |= SERIAL_CONNEXION_OPEN_SUCCES;
                return 0;
            }
        }
    }
    return -99999;
#endif
}

/**
  * @brief  Get Status (StatusRegValue ne doit normalement jamais valoir 0 -> si c'est le cas c'est probablement que la carte n'a pas r�pondu)
*/
unsigned int getMainStatusReg(HANDLE ComPort){
#ifdef NO_ROBOT
	return THIS_BIT_ALWAYS_SET;
#else
    int     SerialStatus;
    DWORD   BytesWritten;

	for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
		if(lockTx){
			Sleep(1);
		}else{
			lockTx = true;
			private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);
			private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_GET_MAIN_STATUS_REG);
			private_TX_add_CCR();
			PurgeComm(ComPort, PURGE_RXABORT|PURGE_RXCLEAR);
			private_send_txBuffer(ComPort);
			Sleep(1);
			SerialStatus = ReadFile(ComPort, &rxDataBuffer, 7, &BytesWritten, NULL);
			if(SerialStatus && private_RX_check_CCR(0,6)){
				lockTx = false;
				return private_ConvBits2uint32(1);
			}
			lockTx = false;
		}
    }
	return 0;
#endif
}

/**
  * @brief get Uc Program Version
*/
unsigned int getUcProgramVersion(HANDLE ComPort){
#ifdef NO_ROBOT
	return 0;
#else
	unsigned int MainStatusReg = getMainStatusReg(ComPort);
	if(MainStatusReg & PROGRAM_VERSION_LISTED){
		int     SerialStatus;
		DWORD   BytesWritten;

		for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
			if(lockTx){
				Sleep(1);
			}else{
				lockTx = true;
				private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);
				private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_GET_UC_PROGRAM_VERSION);
				private_TX_add_CCR();
				PurgeComm(ComPort, PURGE_RXABORT|PURGE_RXCLEAR);
				private_send_txBuffer(ComPort);
				Sleep(1);
				SerialStatus = ReadFile(ComPort, &rxDataBuffer, 7, &BytesWritten, NULL);
				if(SerialStatus && private_RX_check_CCR(0,6)){
					lockTx = false;
					return private_ConvBits2uint32(1);
				}
				lockTx = false;
			}
		}
		return 0;
	}else{
		return 0;
	}
#endif
}

/**
  * @brief -> If enable the board will send the 3 axis measured positions (and analog input value) at the same rhythm it get new targets
*/
int		syncDataStream_CMD(HANDLE ComPort, FunctionalState NewState, int CheckOk){
#ifdef NO_ROBOT
	return 0;
#else
	for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
		if(lockTx){
			Sleep(1);
		}else{
			lockTx = true;
			private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);
			if(NewState)
				private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_EN_SYNC_DATA_STREAM);
			else
				private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_DIS_SYNC_DATA_STREAM);
			private_TX_add_CCR();
			//PurgeComm(ComPort, PURGE_RXABORT|PURGE_RXCLEAR);
			private_send_txBuffer(ComPort);
			lockTx = false;

			if(CheckOk){ 
				unsigned int MainStatusReg = getMainStatusReg(ComPort);
				if(NewState && (MainStatusReg & SYNC_REPLY_STREAM_EN)){ //OK
					return 0;
				}else if(!NewState && !(MainStatusReg & SYNC_REPLY_STREAM_EN)){ //OK
					return 0;
				}else{	//Not OK
					return -99999;
				}
			}else{
				return 0;
			}
		}
	}
	return -99998;	//Not able to use the Tx 
#endif
}

/**
  * @brief	-> If enable the board will send data at the rythme of the supervision loop (2ms by default)
  *			-> In principle should not be used in this program
*/
int		asyncDataStream_CMD(HANDLE ComPort, FunctionalState NewState, int CheckOk){
#ifdef NO_ROBOT
	return 0;
#else
	for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
		if(lockTx){
			Sleep(1);
		}else{
			lockTx = true;
			private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);
			if(NewState)
				private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_EN_ASYNC_DATA_STREAM);
			else
				private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_DIS_ASYNC_DATA_STREAM);
			private_TX_add_CCR();
			//PurgeComm(ComPort, PURGE_RXABORT|PURGE_RXCLEAR);
			private_send_txBuffer(ComPort);
			lockTx = false;

			if(CheckOk){ 
				unsigned int MainStatusReg = getMainStatusReg(ComPort);
				if(NewState && (MainStatusReg & STREAM_DATA_EN)){ //OK
					return 0;
				}else if(!NewState && !(MainStatusReg & STREAM_DATA_EN)){ //OK
					return 0;
				}else{ //Not OK
					return -99999;
				}
			}else{
				return 0;
			}
		}
	}
	return -99998;	//Not able to use the Tx 
#endif
}

/**
  * @brief   Init axis
*/
void	RequestAllAxisInit(HANDLE ComPort){
#ifdef NO_ROBOT
	return;
#else
	for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
		if(lockTx){
			Sleep(1);
		}else{
			lockTx = true;
			private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);
			private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_AXIS_INIT);
			private_TX_add_CCR();
			private_send_txBuffer(ComPort);
			lockTx = false;
		}
	}
#endif
}

/**
  * @brief  Set motor control param
  *			If CheckOk=1, the function read back the value stored in the uC and return 1->succes 0->error (if CheckOk=0 return=0)
*/
int     axis_set_param(HANDLE ComPort, unsigned char axisID, axis_paramID ParamID, float ParamValue, int CheckOk){
#ifdef NO_ROBOT
	return 1;
#else
	for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
		if(lockTx){
			Sleep(1);
		}else{
			lockTx = true;
			private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);
			private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_SET_AXIS_PARAM);
			private_add_7BitChar_To_TxBuffer(axisID);
			private_add_7BitChar_To_TxBuffer(ParamID);
			private_add_float_To_TxBuffer(ParamValue);
			private_TX_add_CCR();
			private_send_txBuffer(ComPort);
			lockTx = false;

			if(CheckOk){
				float ReadBackValue = axis_get_param(ComPort, axisID, ParamID);
				//cout<<"Rel err : "<<abs(ParamValue-ReadBackValue)/max(max(abs(ParamValue),abs(ReadBackValue)),0.00001f)<<endl;
				if( abs(ParamValue-ReadBackValue)/max(max(abs(ParamValue),abs(ReadBackValue)),0.00001f)>0.01f)
					return 0;
				else
					return 1;
			}else{
				return 0;
			}
		}
	}
	return -99998;	//Not able to use the Tx 
#endif
}

/**
  * @brief  Get axis control param
*/
float   axis_get_param(HANDLE ComPort, unsigned char axisID, axis_paramID ParamID){
#ifdef NO_ROBOT
	return 0.0f;
#else
    int     SerialStatus;
    DWORD   BytesWritten;

	for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
		if(lockTx){
			Sleep(1);
		}else{
			lockTx = true;
			private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);
			private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_GET_AXIS_PARAM);
			private_add_7BitChar_To_TxBuffer(axisID);
			private_add_7BitChar_To_TxBuffer(ParamID);
			private_TX_add_CCR();
			PurgeComm(ComPort, PURGE_RXABORT|PURGE_RXCLEAR);
			private_send_txBuffer(ComPort);
			Sleep(1);
			SerialStatus = ReadFile(ComPort, &rxDataBuffer, 7, &BytesWritten, NULL);
			if(SerialStatus && private_RX_check_CCR(0,6)){
				lockTx = false;
				return private_ConvBits2float(1);
			}
			lockTx = false;
		}
	}
	return -9999999.0f;
#endif
}

/*
*   return 0-> error, 1-> succes 
*   Not used anymore
*/
int		axis_set_all_control_param(HANDLE ComPort){
#ifdef NO_ROBOT
	return 1;
#else
	int Succes = 1;

	for(int i=0; i<3; i++){
		if(!axis_set_param(ComPort, i, positionReg_Kp, Axis[i].PositionReg_Kp, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, positionReg_Kd, Axis[i].PositionReg_Kd, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, positionReg_Ki, Axis[i].PositionReg_Ki, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, positionReg_integLim, Axis[i].PositionReg_IntegLim, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, positionRegCurrentScale, Axis[i].PositionReg_CurrentScale, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, positionRegTs_us, Axis[i].PositionReg_Ts_us, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, currentReg_Kp, Axis[i].CurrentReg_Kp, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, currentReg_Ki, Axis[i].CurrentReg_Ki, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, currentReg_Kv, Axis[i].CurrentReg_Kv, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, currentReg_Kr, Axis[i].CurrentReg_Kr, 1))
			Succes = 0;
		if(!axis_set_param(ComPort, i, coderResol_incRevol, Axis[i].Coder_Resol, 1))
			Succes = 0;
	}
	return Succes;
#endif
}

/**
  * @brief  Enable/disable motor power bridge
  *		If CheckOk=1, the function read back the value stored in the uC and return 0 ->succes -1 ->error (if CheckOk=0 return=0)
  * @param  MotorX_NewState -> ENABLE/DISABLE
  */
int		axis_CMD(HANDLE ComPort, FunctionalState axis0_NewState, FunctionalState axis1_NewState, FunctionalState axis2_NewState, int CheckOk){
#ifdef NO_ROBOT
	return 0;
#else

    unsigned char data = 0;

    if(axis0_NewState)
        data |= axis0_RegID;
    if(axis1_NewState)
        data |= axis1_RegID;
    if(axis2_NewState)
        data |= axis2_RegID;

	for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
		if(lockTx){
			Sleep(1);
		}else{
			lockTx = true;
			private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);
			private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_EN_DIS_AXIS_CMD);
			private_add_7BitChar_To_TxBuffer(data);
			private_TX_add_CCR();
			private_send_txBuffer(ComPort);
			lockTx = false;

			if(CheckOk){
				unsigned int AxisStatusReg;
				float tmpVal;
				tmpVal = axis_get_param(ComPort, 0, status);
				AxisStatusReg = *((unsigned int*)&tmpVal);
				if(((bool)(AxisStatusReg & MOTOR_EN))^((bool)(axis0_NewState)))
					return -1;
				tmpVal = axis_get_param(ComPort, 1, status);
				AxisStatusReg = *((unsigned int*)&tmpVal);
				if(((bool)(AxisStatusReg & MOTOR_EN))^((bool)(axis1_NewState)))
					return -1;
				tmpVal = axis_get_param(ComPort, 2, status);
				AxisStatusReg = *((unsigned int*)&tmpVal);
				if(((bool)(AxisStatusReg & MOTOR_EN))^((bool)(axis2_NewState)))
					return -1;
				return 0;
			}else{
				return 0;
			}
		}
	}
	return -99998;	//Not able to use the Tx 
#endif
}

/**
  * @brief -> If enable the motor emulate a dry friction that allow the robot to be moved by hand without falling
  *			  If CheckOk=1, the function read back the value stored in the uC and return 0 ->succes -1 ->error (if CheckOk=0 return=0)
*/
int		dryFrictionMode_CMD(HANDLE ComPort, FunctionalState NewState, int CheckOk){
#ifdef NO_ROBOT
	return 0;
#else
	for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
		if(lockTx){
			Sleep(1);
		}else{
			lockTx = true;
			private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);
			if(NewState)
				private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_EN_DRY_FRICTION_MODE);
			else
				private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_DIS_DRY_FRICTION_MODE);
			private_TX_add_CCR();
			private_send_txBuffer(ComPort);
			lockTx = false;

			if(CheckOk){ //Check only one off the 3 axis (if one is ok the reste is ok too)
				unsigned int AxisStatusReg;
				float tmpVal;
				tmpVal = axis_get_param(ComPort, 0, status);
				AxisStatusReg = *((unsigned int*)&tmpVal);
				if(((bool)(AxisStatusReg & VIRTUAL_DRY_FRICTION_EN))^((bool)(NewState))){
					return -1;
				}else{
					return 0;
				}
			}else{
				return 0;
			}
		}
	}
	return -99998;	//Not able to use the Tx 
#endif
}

/**
  * @brief  Set current targuet for all motors (value in Ampere)
  *         Note1:  Targuet can be send if the Motors are enabled or disabled (but a targuet sent to a disabled motor will NOT turn it on)
  *         Note2:  During normal operation -> sending current targuets (with Set_AllMotors_Current_Targuet) the control board automatically switch to current regulation mode for all motors
  *                 During normal operation -> sending position targuets (with Set_AllMotors_Position_Targuet) the control board automatically switch to position regulation mode for all motors
  *			Note3:  If "dummyTarget" is set the function will send a wrong data frame to the electronic control board that will be ignored, but if "syncDataStream" mode is enable
  *					the board will still send back the position (and analog input). This is usefull when we don't want to change current/position but we want the measure to be
  *					updated
  */
void    Set_AllMotors_Current_Targuet(HANDLE ComPort, double *MotorCurrent_Amp, int dummyTarget){
#ifdef NO_ROBOT
	return;
#else

    COMSTAT ComState;
	DWORD   Status, BytesWritten;
	int		i;

	if(lockTx){
		return;
	}else{
		lockTx=true;
		private_add_8BitChar_To_TxBuffer(MSG_TYPE_CURRENT_CONTROL);

		if(dummyTarget){ //Create a dummy message with a wrong CCR value -> only to force the board to send back the current position/analog value
			private_add_7BitChar_To_TxBuffer(0);
		}else{
			for(i=0; i<3; i++){
				private_add_float_To_TxBuffer((float)MotorCurrent_Amp[i]);
			}
			private_TX_add_CCR();
		}
		private_send_txBuffer(ComPort);

		ClearCommError(ComPort, &Status, &ComState);
		#ifdef GET_1_ANALOG_INPUT
			if((!Status) && (ComState.cbInQue>31)){
				Status = ReadFile(ComPort, &rxDataBuffer, ComState.cbInQue, &BytesWritten, NULL);
				if(Status && (private_RX_check_CCR(ComState.cbInQue-32,ComState.cbInQue-1))){
					Axis[0].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-31))*DEG2RAG/Axis[0].Gear_GearRatio + Axis[0].AxisPosOffset_rad;			//MotorActualPosDeg[0] = private_ConvBits2float(ComState.cbInQue-31);
					Axis[1].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-26))*DEG2RAG/Axis[1].Gear_GearRatio + Axis[1].AxisPosOffset_rad;			//MotorActualPosDeg[1] = private_ConvBits2float(ComState.cbInQue-26);
					Axis[2].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-21))*DEG2RAG/Axis[2].Gear_GearRatio + Axis[2].AxisPosOffset_rad;			//MotorActualPosDeg[2] = private_ConvBits2float(ComState.cbInQue-21);
					DummyAnalogInput[0]  = private_ConvBits2float(ComState.cbInQue-16);
					DummyAnalogInput[1]  = private_ConvBits2float(ComState.cbInQue-11);
					DummyAnalogInput[2]  = private_ConvBits2float(ComState.cbInQue-6);
				}
			}
		#else
			#ifdef GET_AXIS_TORQUE 
				if((!Status) && (ComState.cbInQue>31)){
					Status = ReadFile(ComPort, &rxDataBuffer, ComState.cbInQue, &BytesWritten, NULL);
					if(Status && (private_RX_check_CCR(ComState.cbInQue-32,ComState.cbInQue-1))){
						Axis[0].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-31))*DEG2RAG/Axis[0].Gear_GearRatio + Axis[0].AxisPosOffset_rad;			//MotorActualPosDeg[0] = private_ConvBits2float(ComState.cbInQue-31);
						Axis[1].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-26))*DEG2RAG/Axis[1].Gear_GearRatio + Axis[1].AxisPosOffset_rad;			//MotorActualPosDeg[1] = private_ConvBits2float(ComState.cbInQue-26);
						Axis[2].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-21))*DEG2RAG/Axis[2].Gear_GearRatio + Axis[2].AxisPosOffset_rad;			//MotorActualPosDeg[2] = private_ConvBits2float(ComState.cbInQue-21);
						DummyMotorTorque[0]  = private_ConvBits2float(ComState.cbInQue-16);
						DummyMotorTorque[1]  = private_ConvBits2float(ComState.cbInQue-11);
						DummyMotorTorque[2]  = private_ConvBits2float(ComState.cbInQue-6);
					}
				}
			#else
				if((!Status) && (ComState.cbInQue>16)){
					Status = ReadFile(ComPort, &rxDataBuffer, ComState.cbInQue, &BytesWritten, NULL);
					if(Status && (private_RX_check_CCR(ComState.cbInQue-17,ComState.cbInQue-1))){
						Axis[0].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-16))*DEG2RAG/Axis[0].Gear_GearRatio + Axis[0].AxisPosOffset_rad;			//MotorActualPosDeg[0] = private_ConvBits2float(ComState.cbInQue-16);
						Axis[1].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-11))*DEG2RAG/Axis[1].Gear_GearRatio + Axis[1].AxisPosOffset_rad;			//MotorActualPosDeg[1] = private_ConvBits2float(ComState.cbInQue-11);
						Axis[2].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-6 ))*DEG2RAG/Axis[2].Gear_GearRatio + Axis[2].AxisPosOffset_rad;			//MotorActualPosDeg[2] = private_ConvBits2float(ComState.cbInQue-6);
					}
				}
			#endif
		#endif
		lockTx=false;
	}
#endif
}

/**
  * @brief  Set position targuet for all motors in (value in degree)
  *         Note1:  Targuet can be send if the Motors are enabled or disabled (but a targuet sent to a disabled motor will NOT turn it on)
  *         Note2:  During normal operation -> sending current targuets (with Set_AllMotors_Current_Targuet) the control board automatically switch to current regulation mode for all motors
  *                 During normal operation -> sending position targuets (with Set_AllMotors_Position_Targuet) the control board automatically switch to position regulation mode for all motors
  *			Note3:  If "dummyTarget" is set the function will send a wrong data frame to the electronic control board that will be ignored, but if "syncDataStream" mode is enable
  *					the board will still send back the position (and analog input). This is usefull when we don't want to change current/position but we want the measure to be
  *					updated
  */
void    Set_AllMotors_Position_Targuet(HANDLE ComPort, double *AxisTargetPos_rad, int dummyTarget){
#ifdef NO_ROBOT
	return;
#else
    COMSTAT ComState;
	DWORD   Status, BytesWritten;
	int		i;

	if(lockTx){
		return;
	}else{
		lockTx=true;
		private_add_8BitChar_To_TxBuffer(MSG_TYPE_POSITION_CONTROL);
		if(dummyTarget){ //Create a dummy message with a wrong CCR value -> only to force the board to send back the current position/analog value
			private_add_7BitChar_To_TxBuffer(0);
		}else{
			for(i=0; i<3; i++){
				private_add_float_To_TxBuffer((float)((AxisTargetPos_rad[i]-Axis[i].AxisPosOffset_rad)*Axis[i].Gear_GearRatio*RAD2DEG));
			}
			private_TX_add_CCR();
		}
		private_send_txBuffer(ComPort);

		ClearCommError(ComPort, &Status, &ComState);
		#ifdef GET_1_ANALOG_INPUT
			if((!Status) && (ComState.cbInQue>31)){
				Status = ReadFile(ComPort, &rxDataBuffer, ComState.cbInQue, &BytesWritten, NULL);
				if(Status && (private_RX_check_CCR(ComState.cbInQue-32,ComState.cbInQue-1))){
					Axis[0].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-31))*DEG2RAG/Axis[0].Gear_GearRatio + Axis[0].AxisPosOffset_rad;			//MotorActualPosDeg[0] = private_ConvBits2float(ComState.cbInQue-31);
					Axis[1].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-26))*DEG2RAG/Axis[1].Gear_GearRatio + Axis[1].AxisPosOffset_rad;			//MotorActualPosDeg[1] = private_ConvBits2float(ComState.cbInQue-26);
					Axis[2].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-21))*DEG2RAG/Axis[2].Gear_GearRatio + Axis[2].AxisPosOffset_rad;			//MotorActualPosDeg[2] = private_ConvBits2float(ComState.cbInQue-21);
					DummyAnalogInput[0]  = private_ConvBits2float(ComState.cbInQue-16);
					DummyAnalogInput[1]  = private_ConvBits2float(ComState.cbInQue-11);
					DummyAnalogInput[2]  = private_ConvBits2float(ComState.cbInQue-6);
				}
			}
		#else
			#ifdef GET_AXIS_TORQUE 
				if((!Status) && (ComState.cbInQue>31)){
					Status = ReadFile(ComPort, &rxDataBuffer, ComState.cbInQue, &BytesWritten, NULL);
					if(Status && (private_RX_check_CCR(ComState.cbInQue-32,ComState.cbInQue-1))){
						Axis[0].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-31))*DEG2RAG/Axis[0].Gear_GearRatio + Axis[0].AxisPosOffset_rad;			//MotorActualPosDeg[0] = private_ConvBits2float(ComState.cbInQue-31);
						Axis[1].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-26))*DEG2RAG/Axis[1].Gear_GearRatio + Axis[1].AxisPosOffset_rad;			//MotorActualPosDeg[1] = private_ConvBits2float(ComState.cbInQue-26);
						Axis[2].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-21))*DEG2RAG/Axis[2].Gear_GearRatio + Axis[2].AxisPosOffset_rad;			//MotorActualPosDeg[2] = private_ConvBits2float(ComState.cbInQue-21);
						DummyMotorTorque[0]  = private_ConvBits2float(ComState.cbInQue-16);
						DummyMotorTorque[1]  = private_ConvBits2float(ComState.cbInQue-11);
						DummyMotorTorque[2]  = private_ConvBits2float(ComState.cbInQue-6);
					}
				}
			#else
				if((!Status) && (ComState.cbInQue>16)){
					Status = ReadFile(ComPort, &rxDataBuffer, ComState.cbInQue, &BytesWritten, NULL);
					if(Status && (private_RX_check_CCR(ComState.cbInQue-17,ComState.cbInQue-1))){
						Axis[0].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-16))*DEG2RAG/Axis[0].Gear_GearRatio + Axis[0].AxisPosOffset_rad;			//MotorActualPosDeg[0] = private_ConvBits2float(ComState.cbInQue-16);
						Axis[1].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-11))*DEG2RAG/Axis[1].Gear_GearRatio + Axis[1].AxisPosOffset_rad;			//MotorActualPosDeg[1] = private_ConvBits2float(ComState.cbInQue-11);
						Axis[2].AxisMeasuredPos_rad = ((double)private_ConvBits2float(ComState.cbInQue-6 ))*DEG2RAG/Axis[2].Gear_GearRatio + Axis[2].AxisPosOffset_rad;			//MotorActualPosDeg[2] = private_ConvBits2float(ComState.cbInQue-6);
					}
				}
			#endif
		#endif
		lockTx=false;
	}
#endif
}

/**
  * @brief  This function set the position offset values of every axis
  *			the "AxisActualPos_rad" will become the return value of "Request_AllAxis_Position" and
  *			"Get_AllAxis_Last_Recieved_Position" when the robot is in this position
  */
int		Set_AllAxis_Position_Offset(HANDLE ComPort, double *AxisActualPos_rad){
#ifdef NO_ROBOT
	Axis[0].AxisMeasuredPos_rad = 0;
	Axis[1].AxisMeasuredPos_rad = 0;
	Axis[2].AxisMeasuredPos_rad = 0;
	Axis[0].AxisPosOffset_rad = AxisActualPos_rad[0];
	Axis[1].AxisPosOffset_rad = AxisActualPos_rad[1];
	Axis[2].AxisPosOffset_rad = AxisActualPos_rad[2];
	LocalStatus |= ALL_AXIS_OFFSET_SUCCES;
	return 0;
#else

	unsigned int mainStatusReg, mainStatusReg2, AxisStatusReg;
	float tmpVal;

	mainStatusReg = getMainStatusReg(ComPort);
	if(mainStatusReg==0)
		return -999999;	//Unable to read status reg

	if(mainStatusReg & AXIS_INIT_IN_PROGRESS)
		return -99998;	//Axis calibration not finished

	for(int i=0; i<3; i++){
		tmpVal = axis_get_param(ComPort, i, status);
		if(tmpVal==-9999999.0f)
			return -99997; //Unable to read AxisStatusReg
		AxisStatusReg = *((unsigned int*)&tmpVal);
		if(!(AxisStatusReg & AXIS_INIT_SUCCES))
			return -99996; //Axis calibration not done (or failed)
	}
	LocalStatus |= ALL_AXIS_INIT_SUCCES;
	Sleep(20);

	for(int i=0;i<=MAX_REQUEST_ATTEMPS;i++){
		if(lockTx){
			Sleep(1);
		}else{
			lockTx = true;
			//Anciennement "Set_Zero_Ref_position(ComPort)" -> For the board to consider current axis position to be {0,0,0}
			private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);		//Anciennement "Set_Zero_Ref_position(ComPort)"
			private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_SET_ZERO_REF);	//Anciennement "Set_Zero_Ref_position(ComPort)"
			private_TX_add_CCR();											//Anciennement "Set_Zero_Ref_position(ComPort)"
			private_send_txBuffer(ComPort);									//Anciennement "Set_Zero_Ref_position(ComPort)"
			lockTx = false;

			Sleep(1);
			mainStatusReg2 = getMainStatusReg(ComPort);
			if((mainStatusReg & GENERAL_PURPOSE_TOGGLE_FLAG) != (mainStatusReg2 & GENERAL_PURPOSE_TOGGLE_FLAG)){
				Axis[0].AxisMeasuredPos_rad = 0;
				Axis[1].AxisMeasuredPos_rad = 0;
				Axis[2].AxisMeasuredPos_rad = 0;
				Axis[0].AxisPosOffset_rad = AxisActualPos_rad[0];
				Axis[1].AxisPosOffset_rad = AxisActualPos_rad[1];
				Axis[2].AxisPosOffset_rad = AxisActualPos_rad[2];
				LocalStatus |= ALL_AXIS_OFFSET_SUCCES;
				return 0;
			}else{
				Sleep(1);
			}
		}
	}
	return -99995; //unable to change offset value
#endif
}

/*
* @brief  set 0 value for analor input
*/
void	Set_AllAnalogInput_Offset(void){
	DummyAnalogInputOffset[0] = DummyAnalogInput[0];
	DummyAnalogInputOffset[1] = DummyAnalogInput[1];
	DummyAnalogInputOffset[2] = DummyAnalogInput[2];
}

/*
* @brief  return the 3 axis positions (If Synchronous_Data_Stream_CMD has been disabled the value will be outdated)
*		 -During regular operation, the driver board will send the current position (and other data) every time it
*		  recive a new position or current target from the computer, thus the "Get_AllAxis_Last_Recieved_Position"
*		  function will give the position of the robot (with about 1-2ms delay)
*		 -If the robot is still in the initialisation phase (or the "asyncDataStream" has not been enabled) the 
*		  position (and other value) can be read using the "Request_..." functions
*/
void	Get_AllAxis_Last_Recieved_Position(double *AxisMeasuredPos_rad){
	AxisMeasuredPos_rad[0] = Axis[0].AxisMeasuredPos_rad;
	AxisMeasuredPos_rad[1] = Axis[1].AxisMeasuredPos_rad;
	AxisMeasuredPos_rad[2] = Axis[2].AxisMeasuredPos_rad;
}

/*
* @brief  return analog value mesured by the board (If Synchronous_Data_Stream_CMD has been disabled the value will be outdated)
*		 -During regular operation, the driver board will send the analog value (and other data) every time it
*		  recive a new position or current target from the computer, thus the "Get_AllAnalogInput_Last_Recieved_Value"
*		  function will give the analog value measured by the input (with about 1-2ms delay)
*		 -If the robot is still in the initialisation phase (or the "asyncDataStream" has not been enabled) the 
*		  analog value (and other value) can be read using the "Request_..." functions
*/
void	Get_AllAnalogInput_Last_Recieved_Value(double *AnalogInput){
	AnalogInput[0] = ((double)DummyAnalogInput[0] - DummyAnalogInputOffset[0])*ANALOG_INPUT_SCALING_GAIN;
	AnalogInput[1] = ((double)DummyAnalogInput[1] - DummyAnalogInputOffset[1])*ANALOG_INPUT_SCALING_GAIN;
	AnalogInput[2] = ((double)DummyAnalogInput[2] - DummyAnalogInputOffset[2])*ANALOG_INPUT_SCALING_GAIN;
}

// ############################################################################################

// Private function

// ############################################################################################


/**
  * @brief  Reconstruit un uint32 � partir de 5 charact�res (7 bites utiles)
  * @param  Variable
	* 				 - Uint32ByteStartID : 	ID of the first byte of the float
  * @retval None
  */
static unsigned int	private_ConvBits2uint32(unsigned char Uint32ByteStartID){
	unsigned int TMP = 0x00000000;
	TMP = (rxDataBuffer[Uint32ByteStartID]<<25) | (rxDataBuffer[(unsigned char)(Uint32ByteStartID+1)]<<18) | (rxDataBuffer[(unsigned char)(Uint32ByteStartID+2)]<<11) | (rxDataBuffer[(unsigned char)(Uint32ByteStartID+3)]<<4) | (rxDataBuffer[(unsigned char)(Uint32ByteStartID+4)]>>3);
	return TMP;
}

/**
  * @brief  Reconstruit un float � partir de 5 charact�res (7 bites utiles)
  * @param  Variable
	* 				 - FloatByteStartID : 	ID of the first byte of the float
  * @retval None
  */
static float	private_ConvBits2float(unsigned char FloatByteStartID){
	unsigned int TMP = 0x00000000;
	TMP = (rxDataBuffer[FloatByteStartID]<<25) | (rxDataBuffer[(unsigned char)(FloatByteStartID+1)]<<18) | (rxDataBuffer[(unsigned char)(FloatByteStartID+2)]<<11) | (rxDataBuffer[(unsigned char)(FloatByteStartID+3)]<<4) | (rxDataBuffer[(unsigned char)(FloatByteStartID+4)]>>3);
	return *((float*)&TMP);
}

/**
  * @brief  Ajoute 7bit (unsigned char) avec 7 bit utile au buffer d'envoi
  */
static void		private_add_8BitChar_To_TxBuffer(unsigned char DATA){
	if(txBufferID){
		txDataBuffer1[txBufferCnt] = DATA;
	}else{
		txDataBuffer0[txBufferCnt] = DATA;
	}
	txBufferCnt++;
}

/**
  * @brief  Ajoute 7bit (unsigned char) avec 7 bit utile au buffer d'envoi
  */
static void		private_add_7BitChar_To_TxBuffer(unsigned char DATA){
	if(txBufferID){
		txDataBuffer1[txBufferCnt] = DATA & 0x7F;
	}else{
		txDataBuffer0[txBufferCnt] = DATA & 0x7F;
	}
	txBufferCnt++;
}

/**
  * @brief  Ajoute un unsigned int au buffer d'envoi
  */
static void		private_add_uint32_To_TxBuffer(unsigned int DATA){
	if(txBufferID){
		txDataBuffer1[txBufferCnt]=((unsigned char)(DATA>>25))&0x7F;
		txDataBuffer1[txBufferCnt+1]=((unsigned char)(DATA>>18))&0x7F;
		txDataBuffer1[txBufferCnt+2]=((unsigned char)(DATA>>11))&0x7F;
		txDataBuffer1[txBufferCnt+3]=((unsigned char)(DATA>>4))&0x7F;
		txDataBuffer1[txBufferCnt+4]=((unsigned char)(DATA<<3))&0x7F;
	}else{
		txDataBuffer0[txBufferCnt]=((unsigned char)(DATA>>25))&0x7F;
		txDataBuffer0[txBufferCnt+1]=((unsigned char)(DATA>>18))&0x7F;
		txDataBuffer0[txBufferCnt+2]=((unsigned char)(DATA>>11))&0x7F;
		txDataBuffer0[txBufferCnt+3]=((unsigned char)(DATA>>4))&0x7F;
		txDataBuffer0[txBufferCnt+4]=((unsigned char)(DATA<<3))&0x7F;
	}
	txBufferCnt+=5;
}

/**
  * @brief  Ajoute une variable de type "float" au buffer d'envoie
  */
static void		private_add_float_To_TxBuffer(float DATA){
	unsigned int TMP=*((unsigned int*)&	DATA);

	if(txBufferID){
		txDataBuffer1[txBufferCnt]=((unsigned char)(TMP>>25));
		txDataBuffer1[txBufferCnt+1]=((unsigned char)(TMP>>18))&0x7F;
		txDataBuffer1[txBufferCnt+2]=((unsigned char)(TMP>>11))&0x7F;
		txDataBuffer1[txBufferCnt+3]=((unsigned char)(TMP>>4))&0x7F;
		txDataBuffer1[txBufferCnt+4]=((unsigned char)(TMP<<3))&0x7F;
	}else{
		txDataBuffer0[txBufferCnt]=((unsigned char)(TMP>>25));
		txDataBuffer0[txBufferCnt+1]=((unsigned char)(TMP>>18))&0x7F;
		txDataBuffer0[txBufferCnt+2]=((unsigned char)(TMP>>11))&0x7F;
		txDataBuffer0[txBufferCnt+3]=((unsigned char)(TMP>>4))&0x7F;
		txDataBuffer0[txBufferCnt+4]=((unsigned char)(TMP<<3))&0x7F;
	}
	txBufferCnt+=5;
}

/**
  * @Verif. Rx CCR return 1 if CCR ok, 0 otherwise
  */
static int		private_RX_check_CCR(int RxBufferMsgStartID, int RxBufferMsgEndID){
	unsigned char CCR=0;

	for(int i=RxBufferMsgStartID; i<RxBufferMsgEndID; i++)
		CCR^= rxDataBuffer[i];

	if((CCR&0x7F)==rxDataBuffer[RxBufferMsgEndID])
		return 1;
	else
		return 0;
}

/**
  * @brief  Add check sum to TxBuffer
  */
static void		private_TX_add_CCR(void){
    unsigned char CCR=0;

 	if(txBufferID){
        for(int i=0; i<txBufferCnt; i++){
            CCR^= txDataBuffer1[i];
        }
	}else{
        for(int i=0; i<txBufferCnt; i++){
            CCR^= txDataBuffer0[i];
        }
	}
	private_add_7BitChar_To_TxBuffer(CCR);
}

/**
  * @brief  Clear tx
  */
static void		private_reset_txBuffer(void){
	txBufferCnt = 0;
}

/**
  * @brief  Send
  */
static void		private_send_txBuffer(HANDLE ComPort){
    int     Status;
    DWORD   BytesWritten;

	if(txBufferID){
		txDataBuffer1[txBufferCnt] = MSG_STOP;
		txBufferCnt++;
        Status = WriteFile(ComPort, &txDataBuffer1, txBufferCnt, &BytesWritten, NULL);
        if(!Status){
            //Add error handling
        }
        while(BytesWritten<txBufferCnt){
            //Add timeout + error handling
        }
		txBufferID = 0;
	}else{
		txDataBuffer0[txBufferCnt] = MSG_STOP;
		txBufferCnt++;
        Status = WriteFile(ComPort, &txDataBuffer0, txBufferCnt, &BytesWritten, NULL);
        if(!Status){
            //Add error handling
        }
        while(BytesWritten<txBufferCnt){
            //Add timeout + error handling
        }
		txBufferID = 1;
	}
	txBufferCnt = 0;
}


// ############################################################################################

// Obsolete function (should not be used anymore)

// ############################################################################################


/* 
* @brief  get the 3 axis angular position from the driver board (shouldn't be used anymore)
*		   - During regular operation of the robot (and if the "syncDataStream" is enable) use rather the "Get_AllAxis_Last_Recieved_Position" to get the position
*		   - During initialisation of the robot (and if the "syncDataStream" is enable) send "dummyTarget" to force the electronic board to send position, and use  
*			 the "Get_AllAxis_Last_Recieved_Position" 
*/
void	Request_AllAxis_Position(HANDLE ComPort, double *AxisMeasuredPos_rad){
#ifdef NO_ROBOT
	AxisMeasuredPos_rad[0]  = 0.0;
	AxisMeasuredPos_rad[1]  = 0.0;
	AxisMeasuredPos_rad[2]  = 0.0;
#else
	// !!! Ajouter un m�chanisme de ccr car suivant quan cette fonction est appel�e il y a bcp de risque de m�langer des donn�es de plusieurs paquets !
	int     Status;
    DWORD   BytesWritten;
    float   ParamValue;
    private_add_8BitChar_To_TxBuffer(MSG_TYPE_GET_POSITION);
    private_TX_add_CCR();
    PurgeComm(ComPort, PURGE_RXABORT|PURGE_RXCLEAR);
    private_send_txBuffer(ComPort);

    Status = ReadFile(ComPort, &rxDataBuffer, 16, &BytesWritten, NULL);
    if(Status){
	//	MotorActualPosDeg[0] = private_ConvBits2float(1);
	//	MotorActualPosDeg[1] = private_ConvBits2float(6);
	//	MotorActualPosDeg[2] = private_ConvBits2float(11);	
        Axis[0].AxisMeasuredPos_rad	= ((double)private_ConvBits2float(1)) *DEG2RAG/Axis[0].Gear_GearRatio + Axis[0].AxisPosOffset_rad;
		Axis[1].AxisMeasuredPos_rad	= ((double)private_ConvBits2float(6)) *DEG2RAG/Axis[1].Gear_GearRatio + Axis[1].AxisPosOffset_rad;
		Axis[2].AxisMeasuredPos_rad	= ((double)private_ConvBits2float(11))*DEG2RAG/Axis[2].Gear_GearRatio + Axis[2].AxisPosOffset_rad;
		AxisMeasuredPos_rad[0]	= Axis[0].AxisMeasuredPos_rad;
		AxisMeasuredPos_rad[1]	= Axis[1].AxisMeasuredPos_rad;
		AxisMeasuredPos_rad[2]	= Axis[2].AxisMeasuredPos_rad;
	}
#endif
}

/* 
* @brief  get the 3 analog input values from the driver board (shouldn't be used anymore)
*		   - During regular operation of the robot (and if the "syncDataStream" is enable) use rather the "Get_AllAnalogInput_Last_Recieved_Value" 
*		   - During initialisation of the robot (and if the "syncDataStream" is enable) send "dummyTarget" to force the electronic board to send position, and use  
*			 the "Get_AllAnalogInput_Last_Recieved_Value" 
*/
void	Request_AllAnalogInput(HANDLE ComPort, double *AnalogInput){
#ifdef NO_ROBOT
	AnalogInput[0]  = 0.0;
	AnalogInput[1]  = 0.0;
	AnalogInput[2]  = 0.0;
#else
	// !!! Ajouter un m�chanisme de ccr car suivant quan cette fonction est appel�e il y a bcp de risque de m�langer des donn�es de plusieurs paquets !
	int     Status;
    DWORD   BytesWritten;
    float   ParamValue;
    private_add_8BitChar_To_TxBuffer(MSG_TYPE_GET_ANALOG_INPUT);
    private_TX_add_CCR();
    PurgeComm(ComPort, PURGE_RXABORT|PURGE_RXCLEAR);
    private_send_txBuffer(ComPort);

    Status = ReadFile(ComPort, &rxDataBuffer, 16, &BytesWritten, NULL);
    if(Status){
        AnalogInput[0]  = ((double)private_ConvBits2float(1))*ANALOG_INPUT_SCALING_GAIN;
		AnalogInput[1]  = ((double)private_ConvBits2float(6))*ANALOG_INPUT_SCALING_GAIN;
		AnalogInput[2]  = ((double)private_ConvBits2float(11))*ANALOG_INPUT_SCALING_GAIN;
	}
#endif
}

///**
//  * @brief  This function set the position offset values of every axis
//  *			the "AxisActualPos_rad" will become the return value of "Request_AllAxis_Position" and
//  *			"Get_AllAxis_Last_Recieved_Position" when the robot is in this position
//  */
//void	Set_AllAxis_Position_Offset(HANDLE ComPort, double *AxisActualPos_rad){
//	//Axis[0].AxisPosOffset_rad += AxisActualPos_rad[0] - Axis[0].AxisMeasuredPos_rad;
//	//Axis[1].AxisPosOffset_rad += AxisActualPos_rad[1] - Axis[1].AxisMeasuredPos_rad;
//	//Axis[2].AxisPosOffset_rad += AxisActualPos_rad[2] - Axis[2].AxisMeasuredPos_rad;
//
//	//Anciennement "Set_Zero_Ref_position(ComPort)" -> For the board to consider current axis position to be {0,0,0}
//	private_add_8BitChar_To_TxBuffer(MSG_TYPE_GENERAL_CONFIG);		//Anciennement "Set_Zero_Ref_position(ComPort)"
//    private_add_7BitChar_To_TxBuffer(CONFIG_REQUEST_SET_ZERO_REF);	//Anciennement "Set_Zero_Ref_position(ComPort)"
//    private_TX_add_CCR();											//Anciennement "Set_Zero_Ref_position(ComPort)"
//    private_send_txBuffer(ComPort);									//Anciennement "Set_Zero_Ref_position(ComPort)"
//
//	Axis[0].AxisMeasuredPos_rad = 0;
//	Axis[1].AxisMeasuredPos_rad = 0;
//	Axis[2].AxisMeasuredPos_rad = 0;
//	Axis[0].AxisPosOffset_rad = AxisActualPos_rad[0];
//	Axis[1].AxisPosOffset_rad = AxisActualPos_rad[1];
//	Axis[2].AxisPosOffset_rad = AxisActualPos_rad[2];
//}
